package oracle.summit.selfservice.backing;

import javax.faces.event.ActionEvent;

public class OrderCreationBean {
    public OrderCreationBean() {
    }

    public void addToOrder(ActionEvent actionEvent) {
        // Add event code here...
    }
}
