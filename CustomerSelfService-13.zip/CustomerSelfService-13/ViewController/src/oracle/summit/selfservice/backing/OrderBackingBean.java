package oracle.summit.selfservice.backing;

import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.layout.RichPanelHeader;

import org.apache.myfaces.trinidad.event.DisclosureEvent;

public class OrderBackingBean {
    private RichPanelHeader productCatPanel;
    private RichTable searchResultsTable;
    private RichTable categoryResultsTable;

    public OrderBackingBean() {
    }

    public void browseTabDisclosureListener(DisclosureEvent disclosureEvent) {
        // Add event code here...
    }

    public void searchTabDisclosureListener(DisclosureEvent disclosureEvent) {
        // Add event code here...
    }

    public void setProductCatPanel(RichPanelHeader productCatPanel) {
        this.productCatPanel = productCatPanel;
    }

    public RichPanelHeader getProductCatPanel() {
        return productCatPanel;
    }

    public void setSearchResultsTable(RichTable searchResultsTable) {
        this.searchResultsTable = searchResultsTable;
    }

    public RichTable getSearchResultsTable() {
        return searchResultsTable;
    }

    public void setCategoryResultsTable(RichTable categoryResultsTable) {
        this.categoryResultsTable = categoryResultsTable;
    }

    public RichTable getCategoryResultsTable() {
        return categoryResultsTable;
    }
}
