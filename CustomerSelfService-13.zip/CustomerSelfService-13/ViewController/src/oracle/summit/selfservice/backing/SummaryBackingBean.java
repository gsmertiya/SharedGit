package oracle.summit.selfservice.backing;

import javax.faces.event.ActionEvent;

public class SummaryBackingBean {
    public SummaryBackingBean() {
    }

    public void placeOrder(ActionEvent actionEvent) {
        // Add event code here...
    }
}
