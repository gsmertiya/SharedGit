package oracle.summit.selfservice.beans;

import javax.faces.event.ActionEvent;

public class TestExceptionHandler {

public TestExceptionHandler() {
}

public void throwNPE(ActionEvent actionEvent) {
     throw new NullPointerException("Exception for throwNPE method in TestHandler");

    }

}