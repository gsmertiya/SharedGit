package oracle.summit.selfservice.backing;

import oracle.adf.model.BindingContext;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.layout.RichPanelHeader;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.BindingContainer;

import oracle.binding.OperationBinding;

import org.apache.myfaces.trinidad.event.DisclosureEvent;

public class OrderBackingBean {
    private RichPanelHeader productCatPanel;
    private RichTable searchResultsTable;
    private RichTable categoryResultsTable;

    public OrderBackingBean() {
    }

    public void browseTabDisclosureListener(DisclosureEvent disclosureEvent) {

        //Render table that contains products in selected category
        getCategoryResultsTable().setRendered(true);
        //Do not render table that contains search results
        getSearchResultsTable().setRendered(false);
        //Get a reference to the current ADF Faces context
        AdfFacesContext adfFacesContext = AdfFacesContext.getCurrentInstance(); 
        //Add a parital target to Product Catalog panel header
        adfFacesContext.addPartialTarget(getProductCatPanel());

        //Get the binding for the page
        BindingContainer bindings = BindingContext.getCurrent().getCurrentBindingsEntry();
        //Get operation binding for method that sets view criteria
        OperationBinding operationBinding = bindings.getOperationBinding("unsetFilterProductsByIdOrNameVC");
        //Exectue the operation binding for the method
        operationBinding.execute();
        //Get operation binding for method that clears result view
        OperationBinding operationBinding2 = bindings.getOperationBinding("resetQueryResults");
        //Exectue the operation binding for the method
        operationBinding2.execute();           
    }

    public void searchTabDisclosureListener(DisclosureEvent disclosureEvent) {

        //Render table that contains search results
        getCategoryResultsTable().setRendered(false);
        //Do not render table that contains products in selected cat
        getSearchResultsTable().setRendered(true);
        //Get a reference to the current ADF Faces context
        AdfFacesContext adfFacesContext = AdfFacesContext.getCurrentInstance(); 
        //Add a partial target to Product Catalog panel header
        adfFacesContext.addPartialTarget(getProductCatPanel());
    }

    public void setProductCatPanel(RichPanelHeader productCatPanel) {
        this.productCatPanel = productCatPanel;
    }

    public RichPanelHeader getProductCatPanel() {
        return productCatPanel;
    }

    public void setSearchResultsTable(RichTable searchResultsTable) {
        this.searchResultsTable = searchResultsTable;
    }

    public RichTable getSearchResultsTable() {
        return searchResultsTable;
    }

    public void setCategoryResultsTable(RichTable categoryResultsTable) {
        this.categoryResultsTable = categoryResultsTable;
    }

    public RichTable getCategoryResultsTable() {
        return categoryResultsTable;
    }
}
