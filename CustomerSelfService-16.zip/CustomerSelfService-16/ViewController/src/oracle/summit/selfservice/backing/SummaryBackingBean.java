package oracle.summit.selfservice.backing;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;

import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

import org.apache.myfaces.trinidad.render.ExtendedRenderKitService;
import org.apache.myfaces.trinidad.util.Service;

public class SummaryBackingBean {
    public SummaryBackingBean() {
    }

    public void placeOrder(ActionEvent actionEvent) {
            
        //Get the binding context and the binding container     
        BindingContainer bindings = BindingContext.getCurrent().getCurrentBindingsEntry();
        //Get the binding for the built-in commit operation
        OperationBinding operationBinding = bindings.getOperationBinding("Commit");
        //Execute the operation binding
        operationBinding.execute();        
        //Close the popup    
        closePopup("p1"); 
    }
            
    /**
    * Closes the RichPopup based on the id.
    *
    */
    public void closePopup(String popupId) {
        FacesContext context = FacesContext.getCurrentInstance();
        ExtendedRenderKitService extRenderKitSrvc = Service.getRenderKitService(context, ExtendedRenderKitService.class);
        extRenderKitSrvc.addScript(context, "AdfPage.PAGE.findComponent('" + popupId + "').hide();");
    }

}
