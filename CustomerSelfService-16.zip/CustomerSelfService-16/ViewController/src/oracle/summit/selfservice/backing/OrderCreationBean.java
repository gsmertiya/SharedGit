package oracle.summit.selfservice.backing;

import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.binding.AttributeBinding;
import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

import oracle.jbo.server.RowImpl;

import oracle.jbo.domain.Number;

public class OrderCreationBean {
    private RowImpl currRow;

    public void setCurrRow(RowImpl currRow) {
        this.currRow = currRow;
    }

    public RowImpl getCurrRow() {
        return currRow;
    }

    public OrderCreationBean() {
    }

    public void addToOrder(ActionEvent actionEvent) {

        //Get access to the binding context
        BindingContainer bindings = BindingContext.getCurrent().getCurrentBindingsEntry();

        //Create new order for first item added
        //Get access to OrdersForCustomer iterator
        DCBindingContainer dcbindings = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        DCIteratorBinding iter = dcbindings.findIteratorBinding("OrdersForCustomerIterator");
        //Get the row count to determine if there are orders
        Long rowCount = iter.getEstimatedRowCount();
        Integer rowCountInt = rowCount.intValue();
        //Check if order is filled
        AttributeBinding atb = (AttributeBinding) bindings.getControlBinding("OrderFilled");
        String orderFilled = (String) atb.getInputValue();

        //If there is no order, create new order
        if (rowCountInt == 0) {
            createOrder();
        }

        //If current order is filled, create new order
        else if (orderFilled != null && orderFilled.equals("Y")) {
            createOrder();
        }
        
        //Add selected item to order 
        addItemToOrder();
    }

    public void createOrder() {
        //Get binding for the built-in create operation
        BindingContainer bindings = BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding operationBinding1 = bindings.getOperationBinding("CreateWithParams");
        //Get customer Id from attribute value binding
        AttributeBinding atb2 = (AttributeBinding) bindings.getControlBinding("Id");
        Integer custId = (Integer) atb2.getInputValue();
        //Set parameter for the CreateWithParams operation
        operationBinding1.getParamsMap().put("CustomerId", custId);
        //Execute the operation binding
        operationBinding1.execute();
    }

    public void addItemToOrder() {
        //Get binding for the built-in create operation
        BindingContainer bindings = BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding operationBinding = bindings.getOperationBinding("CreateWithParams1");
        //Get prodId from product Id in the current row
        Integer prodId = (Integer) currRow.getAttribute("Id");
        //Get price from SuggestedWhlslPrice in current row
        Number price = (Number) currRow.getAttribute("SuggestedWhlslPrice");
        //Set parameters for the CreateWithParams1 operation
        operationBinding.getParamsMap().put("ProductId", prodId);
        operationBinding.getParamsMap().put("Price", price);
        //Execute the operation binding
        operationBinding.execute();
    }

}
